from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.contrib.auth.models import User
from django.forms import models

from.models import Profile


class UserForm(UserCreationForm):
    name =forms.CharField(max_length=50)
    address=forms.CharField(max_length=50)
    age = forms.IntegerField()
    email = forms.EmailField(max_length=254, help_text='Required. Inform a valid email address.')
    class meta:
        model = User
        fields =['username','name','password1','password2', 'email','address','age']


class EditProfile(UserChangeForm):
    class Meta:
        model=Profile
        fields=['name', 'email','address','age']