from django.conf.urls import url
from django.urls import path
from django.contrib.auth.views import LoginView,LogoutView
from.import views
app_name = 'login '
urlpatterns=[

    url('login/$', LoginView.as_view(),name='login'),
    # url('log/$',views.login,name='log'),
    url('logout/$', LogoutView.as_view(),name='logout'),
    # url('edit_profile/$', views.UserEditView.as_view(), name='edit_profile'),
    # url('^confirmation',views.confirmation,name='confirmation'),
    # url('edit_profile/$', views.edit_profile, name='edit_profile'),UserEditView
url('edit_profile/$', views.edit_profile, name='edit_profile'),
    path('', views.home,name='home'),
url(r'^(?P<pk>[0-9]+)/$',views.DetailsView.as_view(),name='detail'),
    url('register/$',views.UserFormView.as_view(),name='register'),
    url('^(?P<pk>[0-9]+)/update/$', views.ProfileUpdate.as_view(), name='update'),
    url('^(?P<pk>[0-9]+)/ProfileUpdate/$',views.ProfileUpdate.as_view(), name='ProfileUpdate')


]