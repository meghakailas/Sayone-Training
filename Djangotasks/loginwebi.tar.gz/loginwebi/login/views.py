from django.contrib.auth.forms import UserChangeForm
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404

from django.views import generic
from django.contrib.auth.models import User,auth
from django.views.generic.edit import CreateView,DeleteView,UpdateView
from django.urls import reverse_lazy, reverse
from django.contrib.auth import authenticate,login
from django.views.generic import View


from login.models import Profile
from.forms import UserForm,EditProfile
from django.core.mail import send_mail



import cgi
import cgitb
# # Create your views here.
# class IndexView(generic.ListView):
#     template_name = 'login.html'
#
#     def get_queryset(self):
#         return


class UserFormView(View):
    form_class = UserForm
    template_name= 'registration_form.html'

# blank form
    def get(self,request):
        form=self.form_class(None)
        return render(request,self.template_name,{'form':form})

# process data
    def post(self,request):
        form=self.form_class(request.POST)
        if form.is_valid():
            user=form.save(commit=False)
#  cleaning data and normalising it
            user = form.save()
            user.refresh_from_db()  # load the profile instance created by the signal
            user.profile.address = form.cleaned_data.get('address')
            user.profile.age = form.cleaned_data.get('age')
            user.profile.name = form.cleaned_data.get('name')
            user.profile.email = form.cleaned_data.get('email')

            user.save()
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=user.username, password=raw_password)

            # temp=Profile()
            # temp.user=user
            # temp.name= '  '
            # temp.address='  '
            # temp.age="0"
            # temp.mobile="0"
            # temp.email="email@temp.com"
            # temp.save()


            if user is not None:
                if user.is_active:
                    auth.login(request,user)
                    return redirect('login:home')

        return render(request, self.template_name, {'form': form})


class ProfileUpdate(UpdateView):
     model = Profile
     fields = ['name','address','age','email',]
     template_name_suffix = '_update_form'

     def get_success_url(self):
         # view_name = 'update_mymodel'
         return reverse_lazy('login :home', )


def home(request):
    return render(request,'Frontpage.html')


def logon(request):
    if request.user.id is not None:

        return redirect('login :home')
    else:
        return redirect('login :login')

#
# def login(request):
#     username = request.POST.get("Username")
#     password = request.POST.get("password")
#     user = authenticate(username=username, password=password)
#     if user is not None:
#         if user.is_active:
#             auth.login(request, user)
#             return redirect('login :home')
#
#     return redirect('login :logon')


class DetailsView(generic.DetailView):
    model = User
    template_name = 'edit1.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        return context


def edit_profile(request):
    if request.user.id is not None:
        # p = get_object_or_404(User,pk=request.user.id)
        # if p.choice_set.all() is not None:
        # send_mail('trail', 'body of the message', 'Arjun.SayOneTech@gmail.com',
        #           ['arjunk1994@gmail.com', ])
        aid=request.user.id
        try:
            return HttpResponseRedirect(reverse('login :update', args=(request.user.id,)))
        except:
            return redirect('../admin/')

    else:
        return redirect('login :login')


def saveprofile(request,pk):
    if request.method == 'POST':
        temp=Profile()
        aid=request.POST.get('id')
        name =  request.POST.get('name')
        address = request.POST.get('address')
        age = request.POST.get('age')
        mobile = request.POST.get('mobile')
        email = request.POST.get('email')
        Profile.objects.filter(id=aid).update(name=name,address=address,age=age,mobile=mobile,email=email)
        return redirect('login :home')





    #    if request.method == 'POST':
    #         form = EditProfile(request.POST, instance=request.user)
    #
    #         if form.is_valid():
    #             form.save()
    #             return redirect('home')
    #     else:
    #         form = EditProfile(instance=request.user)
    #         args = {'form': form}
    #         return render(request, 'edit.html', args)
    # else:
    #     return render(request, 'login.html')

#
# class UserEditView(View):
#     form_class =EditProfile
#     template_name= 'edit1.html'
#
# # blank form
#     def get(self,request):
#
#         form=UserChangeForm(request.POST, instance=request.user)
#
#         if form.is_valid():
#             form.save()
#             return redirect('/')
#
#         # except:
#         #     form=self.form_class(None)
#         #     args = {'form': form}
#         #     return render(request, 'edit.html', args)
#
#
# # process data
#     def post(self,request):
#         form=self.form_class(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('home')
#         return render(request, self.template_name, {'form': form})
#

def UserEditView(request):
    if request.method=='POST':
        form=EditProfile(request.POST, instance=request.user)

        if form.is_valid():
            form.save()
            return redirect('/')

    else:
        form=EditProfile(instance=request.user)
        args={'form':form}
        return render(request,'edit.html',args)
#
# class UserCreate(CreateView):
#     model = User
#     fields = ["Username","password",'first_name','last_name']
#
# def confirmation(request):
#     return render(request, 'registration.html')