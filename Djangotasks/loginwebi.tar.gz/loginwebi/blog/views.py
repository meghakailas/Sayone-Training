from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render
from django.views import generic
from django.views.generic import View
from django.http import HttpResponse
from django.views.generic.edit import CreateView
from .models import Post
from django.utils import timezone
from .forms import PostForm
from django.shortcuts import redirect
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
import json
# Create your views here.
# class ListView(generic.ListView):
#     model = Post
#     template_name = 'blog/post_list.html'
#     paginate_by = 10
#     ordering = ['-published_date']
from django.shortcuts import get_object_or_404

def post(request):
    if request.user.id is not None:
        postss = Post.objects.filter(published_date__lte=timezone.now()).order_by('-published_date')
        page = request.GET.get('page', 1)
        paginator = Paginator(postss, 3)
        try:
            posts = paginator.page(page)
        except PageNotAnInteger:
            posts = paginator.page(1)
        except EmptyPage:
            posts = paginator.page(paginator.num_pages)
        return render(request,'blog/post_list.html', {'posts1':posts})
    else:
        return redirect('login :login')

# class PostCreate(CreateView):
#     model = Post
#     fields = ['title','text','file']
class DetailsView(generic.DetailView):
    model = Post
    template_name = 'blog/post_details.html'
# def post_detail(request,pk):
#     #post = get_object_or_404(Post, pk=pk)
#     post=Post.objects.get(pk=pk)
#     return render(request, 'blog/post_details.html', {'post': post})


# def post_new(request):
#     if request.method == "POST":
#         form = PostForm(request.POST, request.FILES)
#         if form.is_valid():
#             post = form.save(commit=False)
#             post.author = request.user
#             post.published_date = timezone.now()
#             post.save()
#             return redirect('blog :list', pk=post.pk)
#             #return redirect('')
#     else:
#         form = PostForm()
#     return render(request, 'blog/post_edit.html', {'form': form})

def search(request):
    if request.method == 'GET':
        word =  request.GET.get('search')
        try:
            status = Post.objects.filter(text__icontains=word)
            #Add_prod class contains a column called 'bookname'
        except Post.DoesNotExist:
            status = None
        return render(request,"blog/search.html",{"posts1":status})
    else:
        return render(request,"blog/search.html",{})


class Post_new(View):

    form_class =PostForm
    template_name= 'blog/post_edit.html'

# blank form
    def post(self,request):

        form=PostForm(request.POST, request.FILES)

        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.published_date = timezone.now()
            post.save()
            return redirect('blog :list', pk=post.pk)


# process data
    def get(self,request):

        form = PostForm()
        return render(request, 'blog/post_edit.html', {'form': form})


@login_required
@require_POST
def like(request):
    if request.method == 'POST':
        user = request.user
        text = request.POST.get('text')
        company = get_object_or_404(Post, text=text)

        if Post.likes.filter(id=user.id).exists():

            Post.likes.remove(user)
            message = 'You disliked this'
        else:
            Post.likes.add(user)
            message = 'You liked this'

    ctx = {'likes_count': Post.total_likes, 'message': message}
    # use mimetype instead of content_type if django < 5
    return HttpResponse(json.dumps(ctx), )
