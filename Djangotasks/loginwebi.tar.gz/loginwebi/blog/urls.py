from django.urls import path
from . import views
app_name = 'blog '
urlpatterns=[
    path('', views.post, name="firstpost"),
    path('post/<int:pk>/', views.DetailsView.as_view(), name='list'),
    # path('post/new/', views.post_new, name='post_new'),
    path('post/new/', views.Post_new.as_view(), name='post_new'),
# path('', views.ListView.as_view(), name='firstpost'),
    path('search', views.search, name="search"),
    path('like', views.like, name="like")
]